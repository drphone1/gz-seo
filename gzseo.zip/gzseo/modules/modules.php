<?php
if (!defined('ABSPATH')) exit;
require_once(GZSEO_PLUGIN_DIR.'modules/gzseo.php');
require_once(GZSEO_PLUGIN_DIR.'modules/gsc.php');
require_once(GZSEO_PLUGIN_DIR.'modules/comment.php');
require_once(GZSEO_PLUGIN_DIR.'modules/ai.php');
